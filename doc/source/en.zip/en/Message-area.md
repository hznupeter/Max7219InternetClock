![](images/%E6%B6%88%E6%81%AF%E6%8F%90%E7%A4%BA%E5%8C%BA1.png)

Message Prompt area usually give feedback of code place to the student's. For example, whether compile or upload was successful, what if the failure is; whether successful or import libraries and other news.