![](images/programming%20building%20area1.png)

We usually complete a certain function codes to connection in this area.
The lower right area there is a trash can, students can drag useless codes to the trash, or you can drag directly to the left area(module selection area), you can also remove the code. Of course, click on the code, then click Delete, codes can also be deleted.



In the upper right corner of the region, you can also choose the type of language. So far, Mixly supports English, Spanish, Simplified Chinese and Traditional Chinese. At the left of choice area, there are two arrows. These two arrows are Mixly 0.97 new features: Undo (Ctrl + Z) and Redo (Ctrl + Y).
Undo function is when we write code that accidentally deleted the code, you can click the left arrow or press Ctrl + Z to restore accidentally deleted codes; and while redo is Ctrl + Z On the contrary, it is to restore the previous operation. The student can function by clicking the right arrow or type Ctrl + Y to achieve.
