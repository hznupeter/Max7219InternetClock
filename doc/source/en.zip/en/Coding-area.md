![](images/coding%20area1.png)

This area can be showed or hided by clicking the right arrow. After they drag blocks, students can learn the programming codes in the code area.  All codes are directly generated with the corresponding to blocks. When students drag an instruction, there will be corresponding codes immediately. This plays an important role in student independent learning and self-test.

![](images/codingarea2.png)